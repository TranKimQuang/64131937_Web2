package edu.quangtk.thiGK.ntu64131937;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TranKimQuangFitCmsBlogApplicationTests {

	@Test
	void contextLoads() {
	}

}
