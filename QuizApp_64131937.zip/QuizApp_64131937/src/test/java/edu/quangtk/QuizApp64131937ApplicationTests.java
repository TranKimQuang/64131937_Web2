package edu.quangtk;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuizApp64131937ApplicationTests {

	@Test
	void contextLoads() {
	}

}
