package edu.quangtk;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QuizApp64131937Application {

	public static void main(String[] args) {
		SpringApplication.run(QuizApp64131937Application.class, args);
	}

}
